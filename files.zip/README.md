# MarketSniper IA — backend + web

Esta carpeta une tu página (`public/index.html`) con Gemini a través de un pequeño
servidor (`server.js`) que guarda la API key **solo en el servidor**, nunca en el
navegador ni en el código fuente que se descarga el usuario.

## ⚠️ Antes de nada: revoca la key que compartiste

Pegaste tu API key real en la conversación. Aunque yo no la puse en ningún
archivo, considérala comprometida:

1. Ve a Google AI Studio → API keys (o Google Cloud Console → APIs & Services →
   Credentials, proyecto `gen-lang-client-0950022389`).
2. Borra/revoca la key `AQ.Ab8RN6L9qha0bLsKcM-6COUxrFAobHVdiO_roqtfTfurUTq2fw`.
3. Genera una nueva y úsala solo en tu archivo `.env` (paso siguiente).

## 1. Instalar dependencias

```bash
cd marketsniper
npm install
```

## 2. Configurar la key (nunca en el código)

```bash
cp .env.example .env
```

Edita `.env` y pon tu key nueva:

```
GEMINI_API_KEY=tu_api_key_nueva
GEMINI_MODEL=gemini-3.5-flash
PORT=3000
```

El `.gitignore` ya excluye `.env`, así que no se sube a GitHub por accidente.

## 3. Ejecutar en local

```bash
npm start
```

Abre `http://localhost:3000`. Tu página se sirve desde ahí y el botón de enviar
llama a `/api/analyze`, que es el que habla con Gemini usando la key del
servidor.

## Cómo funciona (resumen)

```
Navegador del usuario          Tu servidor (server.js)         Google Gemini
  fetch('/api/analyze')  ---->   añade la API key   ---->   generativelanguage
  (sin key, solo el mensaje)     desde .env                  googleapis.com
```

La key nunca viaja al navegador: solo vive como variable de entorno en el
servidor.

## 4. Desplegar en producción

Necesitas un hosting que ejecute Node.js (no sirve un hosting estático tipo
GitHub Pages, porque el backend tiene que correr en un servidor). Opciones
sencillas y con capa gratuita:

- **Render** (render.com): "New Web Service" → conecta tu repo → build
  command `npm install`, start command `npm start` → en "Environment"
  agregas `GEMINI_API_KEY` y `GEMINI_MODEL` como variables secretas.
- **Railway** (railway.app): mismo flujo, variables de entorno en la pestaña
  "Variables".
- **Fly.io / un VPS propio**: igual, defines `GEMINI_API_KEY` como variable de
  entorno del proceso, nunca en el código.

En cualquiera de estas plataformas, la key se configura en el panel de
"Environment Variables / Secrets", **no** en un archivo que subas al
repositorio.

## Notas

- El modelo por defecto es `gemini-3.5-flash`. Si Google lo retira o quieres
  usar otro, solo cambia `GEMINI_MODEL` en `.env`, sin tocar `server.js`.
- El endpoint acepta texto y, opcionalmente, una imagen en base64 (así ya lo
  manda tu frontend actual).
- Límite de payload subido a 10MB para permitir fotos; tu frontend ya limita
  las imágenes a 4MB antes de enviarlas.
